using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;


namespace speedyCar
{
    public partial class Form1 : Form
    {
        public static Form1 instance;
        public TextBox tb1;
        public Form1()
        {
            InitializeComponent();
            instance=this;
            tb1 = textBox1;

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        

        private void button2_Click(object sender, EventArgs e)
        {
            //SqlConnection con = new SqlConnection("Data Source=DESKTOP-RIIANEQ\\SQLEXPRESS;Initial Catalog=SpeedyHire;Integrated Security=True");
            SqlConnection con = new SqlConnection("Data Source=LOCALHOST\\SQLEXPRESS;Initial Catalog=SpeedyHire;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into Cars values(@RegNo,@Make,@EngineSize,@DateRegistered,@RentalPerDay,@Available)", con);
            cmd.Parameters.AddWithValue("@RegNo", textBox1.Text);
            cmd.Parameters.AddWithValue("@Make", textBox2.Text);
            cmd.Parameters.AddWithValue("@EngineSize", textBox3.Text);
            cmd.Parameters.AddWithValue("@DateRegistered", DateTime.Parse(dateTimePicker1.Text));
            cmd.Parameters.AddWithValue("@RentalPerDay", double.Parse(textBox4.Text));
            cmd.Parameters.AddWithValue("@Available",  textBox5.Text);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Successfully Saved");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-RIIANEQ\\SQLEXPRESS;Initial Catalog=SpeedyHire;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Update Cars set Make=@Make,EngineSize=@EngineSize,DateRegistered=@DateRegistered,RentalPerDay=@RentalPerDay,Available=@Available where RegNo=@RegNo", con);

            cmd.Parameters.AddWithValue("@RegNo", textBox1.Text);
            cmd.Parameters.AddWithValue("@Make", textBox2.Text);
            cmd.Parameters.AddWithValue("@EngineSize", textBox3.Text);
            cmd.Parameters.AddWithValue("@DateRegistered", DateTime.Parse(dateTimePicker1.Text));
            cmd.Parameters.AddWithValue("@RentalPerDay", double.Parse(textBox4.Text));
            cmd.Parameters.AddWithValue("@Available", textBox5.Text);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Successfully Updated");

        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-RIIANEQ\\SQLEXPRESS;Initial Catalog=SpeedyHire;Integrated Security=True");
            con.Open();

            SqlCommand cmd = new SqlCommand("Delete Cars where RegNo=@RegNo", con);

            cmd.Parameters.AddWithValue("@RegNo", textBox1.Text);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Successfully Deleted");

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Clear();
        }

        void Clear()
        {
            textBox1.Text = textBox2.Text = textBox3.Text = dateTimePicker1.Text = textBox4.Text = textBox5.Text = "";
            //button2.Enabled = false;
            //button3.Enabled = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //SqlConnection con = new SqlConnection("Data Source=DESKTOP-RIIANEQ\\SQLEXPRESS;Initial Catalog=SpeedyHire;Integrated Security=True");
           // SqlConnection con = new SqlConnection("Data Source=LOCALHOST\\SQLEXPRESS;Initial Catalog=SpeedyHire;Integrated Security=True");
           // con.Open();
            //SqlCommand cmd = new SqlCommand("Select * from Cars", con);
            //SqlDataAdapter da = new SqlDataAdapter(cmd);
            //DataTable dt = new DataTable();
            //da.Fill(dt);
            //dataGridView1.DataSource = dt;

            Form2 form = new Form2();
            form.Show();
        }
    }
}